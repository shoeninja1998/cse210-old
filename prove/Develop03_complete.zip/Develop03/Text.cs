public class Text{
    private string _text = @"For God so loved the world, that he gave his only begotten Son,
that whosoever believeth in him should not perish, but have everlasting life.";
    public string DisplayText(){
        return $"{_text}";
    }
}